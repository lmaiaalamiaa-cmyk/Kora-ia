import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const KEY = process.env.API_FOOTBALL_KEY;
const BASE = "https://v3.football.api-sports.io";

const leagues = [
  { id: 39, name: "الدوري الإنجليزي" },
  { id: 140, name: "الدوري الإسباني" },
  { id: 78, name: "الدوري الألماني" },
  { id: 135, name: "الدوري الإيطالي" },
  { id: 61, name: "الدوري الفرنسي" },
  { id: 2, name: "دوري أبطال أوروبا" }
];

async function api(path) {
  if (!KEY) throw new Error("أضف API_FOOTBALL_KEY في ملف .env على الخادم");
  const r = await fetch(`${BASE}${path}`, {
    headers: { "x-apisports-key": KEY }
  });
  if (!r.ok) throw new Error(`مزود البيانات أعاد HTTP ${r.status}`);
  const data = await r.json();
  if (data.errors && Object.keys(data.errors).length) {
    throw new Error(JSON.stringify(data.errors));
  }
  return data.response || [];
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "Kora AI" }));
app.get("/leagues", (_req, res) => res.json(leagues));

app.get("/fixtures", async (req, res) => {
  try {
    const date = req.query.date || new Date().toISOString().slice(0, 10);
    const leagueIds = String(req.query.leagues || "39,140,78,135,61,2")
      .split(",").map(Number).filter(Number.isFinite);
    const season = Number(req.query.season || new Date().getFullYear());
    const all = [];
    for (const id of leagueIds) {
      const rows = await api(`/fixtures?date=${encodeURIComponent(date)}&league=${id}&season=${season}`);
      all.push(...rows);
    }
    all.sort((a,b) => new Date(a.fixture.date) - new Date(b.fixture.date));
    res.json(all);
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});

function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }
function pct(n) { return `${Math.round(clamp(n, 0.05, 0.95) * 100)}%`; }

// Heuristic preview only. Replace with a trained, backtested model before commercial launch.
app.get("/predictions/:fixtureId", async (req, res) => {
  try {
    const rows = await api(`/fixtures?id=${encodeURIComponent(req.params.fixtureId)}`);
    if (!rows.length) return res.status(404).json({ error: "المباراة غير موجودة" });
    const m = rows[0];
    const home = m.teams.home.name, away = m.teams.away.name;
    const homeFav = m.teams.home.id < m.teams.away.id; // placeholder prior, not a real team-strength model
    const pHome = homeFav ? 0.43 : 0.37;
    const pDraw = 0.27;
    const pAway = 1 - pHome - pDraw;
    const predictions = [
      { title: "النتيجة الأقرب", value: homeFav ? `${home} أو تعادل` : `${away} أو تعادل`, probability: pct(Math.max(pHome, pAway) + pDraw * 0.35), note: "تقدير أولي؛ يحتاج إلى نموذج قوة فرق وبيانات تاريخية." },
      { title: "الفائز المحتمل", value: homeFav ? home : away, probability: pct(Math.max(pHome, pAway)), note: "لا يعني ضمان الفوز." },
      { title: "مجموع الأهداف", value: "أكثر من 1.5", probability: "غير معايرة", note: "تقدير مبدئي فقط إلى حين توفر متوسطات التسجيل." },
      { title: "أكثر من 2.5 هدف", value: "غير محسوم", probability: "غير متاح", note: "لا تتوفر حالياً إحصاءات كافية لحساب احتمال موثوق." },
      { title: "الفريقان يسجلان", value: "غير محسوم", probability: "غير متاح", note: "يلزم سجل تهديف واستقبال الأهداف لكل فريق." }
    ];
    res.json({ fixtureId: m.fixture.id, home, away, predictions, disclaimer: "هذه مؤشرات تجريبية وليست تنبؤات مضمونة أو نصيحة مراهنة." });
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});

app.listen(PORT, () => console.log(`Kora AI API listening on ${PORT}`));
